




        <div class="pages">

          <div data-page="index" class="page homepage">
            <div class="page-content">

			    <div class="navbarpages">
  					<div class="navbar_left">
  						<div class="logo_text"><a href="index.html">IDEA</a></div>
  					</div>
    					<div class="navbar_right navbar_right_menu">
    					<a href="#" data-panel="left" class="open-panel"><img src="<?=base_url()?>_template/dashboard/images/icons/white/menu.png" alt="" title="" /></a>
    					</div>
    					<div class="navbar_right">
    					<a href="#" data-panel="right" class="open-panel"><img src="<?=base_url()?>_template/dashboard/images/icons/white/user.png" alt="" title="" /></a>
    					</div>
          </div>
                  <!-- Slider -->
                 <div class="swiper-container slidertoolbar swiper-init" data-effect="slide" data-parallax="true" data-pagination=".swiper-pagination"  data-next-button=".swiper-button-next" data-prev-button=".swiper-button-prev">
                    <div class="swiper-wrapper">

                        <div class="swiper-slide" style="background-image:url(<?=base_url()?>_template/dashboard/images/slide1.jpg);"></div>
                        <div class="swiper-slide" style="background-image:url(<?=base_url()?>_template/dashboard/images/slide2.jpg);"></div>
                        <div class="swiper-slide" style="background-image:url(<?=base_url()?>_template/dashboard/images/slide3.jpg);"></div>
                    </div>
                <div class="swiper-pagination"></div>
            			<div class="swiper-button-prev"></div>
            			<div class="swiper-button-next"></div>
                </div>

		 <div class="swiper-container-toolbar swiper-toolbar swiper-init">
			<div class="swiper-pagination-toolbar"></div>
			<div class="swiper-wrapper">
			  <div class=" toolbar-icon">
				<a href="<?=site_url("dashboard/dashboard/about")?>" data-view=".view-main"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/users.png" alt="" title="" /><span>ABOUT</span></a>
			  <a href="features.html" data-view=".view-main"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/features.png" alt="" title="" /><span>FEATURES</span></a>
				<a href="#" data-popup=".popup-login" class="open-popup"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/lock.png" alt="" title="" /><span>LOGIN</span></a>
				<a href="blog.html" data-view=".view-main"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/blog.png" alt="" title="" /><span>JOURNAL</span></a>
				<a href="photos.html" data-view=".view-main"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/photos.png" alt="" title="" /><span>PHOTOS</span></a>
				<a href="contact.html" data-view=".view-main"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/contact.png" alt="" title="" /><span>CONTACT</span></a>

        <a href="<?=site_url("dashboard/dashboard/about")?>" data-view=".view-main"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/users.png" alt="" title="" /><span>ABOUT</span></a>
			  <a href="features.html" data-view=".view-main"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/features.png" alt="" title="" /><span>FEATURES</span></a>
				<a href="#" data-popup=".popup-login" class="open-popup"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/lock.png" alt="" title="" /><span>LOGIN</span></a>
				<a href="blog.html" data-view=".view-main"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/blog.png" alt="" title="" /><span>JOURNAL</span></a>
				<a href="photos.html" data-view=".view-main"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/photos.png" alt="" title="" /><span>PHOTOS</span></a>
				<a href="contact.html" data-view=".view-main"><img src="<?=base_url()?>_template/dashboard/images/icons/blue/contact.png" alt="" title="" /><span>CONTACT</span></a>
			  </div>

			</div>
		  </div>


            </div>
          </div>
        </div>
