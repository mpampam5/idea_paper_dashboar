</div>
<!-- /.content-wrapper -->


<div id="menu-footer">
  <div class="col-4">
    <i class="fa fa-info"></i>
  </div>
</div>


</div>
<!-- ./wrapper -->




<script src="<?=base_url()?>_template/front/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url()?>_template/front/dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="<?=base_url()?>_template/front/dist/js/pages/dashboard.js"></script> -->
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url()?>_template/front/dist/js/demo.js"></script>
</body>
</html>
